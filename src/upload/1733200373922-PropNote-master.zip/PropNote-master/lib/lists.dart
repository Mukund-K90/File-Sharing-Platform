class SubjectLists {
  static List<String> getSubjects(String MainType) {
    switch ('$MainType') {
      case 'Home':
        return lists.homeType;
      case 'Plots':
        return lists.plotType;
      case 'Commercial':
        return lists.commercialType;
      default:
        return ["None"];
    }
  }
}

class lists {
  static const List<String> mainCategory = ["Home", "Plots", "Commercial"];

  static const List<String> homeType = ['House', 'FarmHouse'];
  static const List<String> plotType = ['Residential', 'Commercial'];
  static const List<String> commercialType = ['Shop', 'Office'];

  static const List<String> areas = [
    "Adajan",
    "Athwa",
    "Bhatha",
    "Bhesan",
    "Bhestan",
    "Chaupati",
    "Chhaprabhatha",
    "Dabholi",
    "Dindoli",
    "Dumas",
    "Godadara",
    "Gothan",
    "Karanj",
    "Katargaam",
    "Kathor",
    "Kosad",
    "Kumbharia",
    "Laskana",
    "Limbayat",
    "Mota Varachha",
    "Nana Varachha",
    "Pal",
    "Palanpore",
    "Pandesara",
    "Pasodara",
    "Puna",
    "Rander",
    "Ring",
    "Road",
    "Sarthana",
    "Udhana",
    "Varachha"
  ];
}
