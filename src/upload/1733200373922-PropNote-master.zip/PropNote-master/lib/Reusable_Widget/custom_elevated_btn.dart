import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../common/utils/colors.dart';

class CustomElevatedButton extends StatelessWidget {
  final double? buttonWidth;
  final VoidCallback onPressed;
  final String text;

  const CustomElevatedButton({
    super.key,
    this.buttonWidth,
    required this.onPressed,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 45,
      width: buttonWidth ?? MediaQuery.of(context).size.width - 20,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              elevation: 0,
              shadowColor: Colors.transparent,
              shape: ContinuousRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              backgroundColor: tealBlue),
          onPressed: onPressed,
          child: Text(
            text,
            style: TextStyle(fontWeight: FontWeight.bold),
          )),
    );
  }
}

class CustomElevatedButton2 extends StatelessWidget {
  final double? buttonWidth;
  final VoidCallback onPressed;
  final String? text;
  final Color bgColor;
  final bool isTitle;
  final IconData? icon;
  final Color? iconColor;


  const CustomElevatedButton2({
    super.key,
    this.buttonWidth,
    required this.onPressed,
    this.text,
    required this.bgColor,this.isTitle=true,this.icon, this.iconColor=tealBlue,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      width: buttonWidth,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              elevation: 0,
              shadowColor: Colors.transparent,
              shape: ContinuousRectangleBorder(
                side: bgColor == Colors.white || bgColor == Colors.transparent
                    ? BorderSide(color: Colors.teal)
                    : BorderSide(color: bgColor),
                borderRadius: BorderRadius.circular(10),
              ),
              backgroundColor: bgColor),
          onPressed: onPressed,
          child:isTitle?Text(
            text!,
            style: TextStyle(
                fontSize: 18,
                color: bgColor == Colors.white || bgColor == Colors.transparent
                    ? tealBlue
                    : Colors.white),
          ):Icon(icon,color: iconColor,size: 20,)),
    );
  }
}
