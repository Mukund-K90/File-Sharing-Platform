import 'package:flutter/material.dart';

import '../common/utils/colors.dart';

class ReusableTextField extends StatelessWidget {
  final TextEditingController? controller;
  final FormFieldValidator<String>? validator;
  final bool obSecure;
  final bool isRequired;
  final TextInputType keyboardType;
  final ValueChanged<String>? onChanged;
  final String? errorText;
  final String? label;
  final Widget? sufIcon;
  final Widget? preIcon;
  final String? title;
  final bool readOnly;
  final bool isMulti;
  final VoidCallback? OnTap;
  final int? maxLength;
  final int? maxLines;

  const ReusableTextField({
    super.key,
    this.controller,
    this.validator,
    this.keyboardType = TextInputType.text,
    this.obSecure = false,
    this.readOnly = false,
    this.isMulti = false,
    this.maxLines,
    this.errorText,
    this.label,
    this.sufIcon,
    this.preIcon,
    this.onChanged,
    this.maxLength,
    this.title,
    this.OnTap,
    this.isRequired = true,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RichText(
              text: TextSpan(style: TextStyle(color: Colors.black),text: '${title}', children: [
            TextSpan(
                style: TextStyle(color: isRequired ? Colors.red : Colors.grey),
                text: isRequired ? ' *' : '(Optional)')
          ])),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.black12,
            ),
            child: Padding(
              padding: const EdgeInsets.only(left: 15),
              child: TextFormField(
                onChanged: onChanged,
                obscureText: obSecure,
                keyboardType: keyboardType,
                controller: controller,
                maxLines: isMulti == true ? maxLines : 1,
                readOnly: readOnly,
                maxLength: maxLength,
                onTap: OnTap,
                cursorColor: tealBlue,
                style: TextStyle(color: tealBlue),
                decoration: InputDecoration(
                  prefixIcon: preIcon,
                  hintText: title,
                  hintStyle: TextStyle(
                      color: Colors.grey.withOpacity(0.9), fontSize: 15),
                  suffixIcon: sufIcon,
                  counterText: '',
                  labelText: label,
                  labelStyle: TextStyle(
                    color: Colors.grey.withOpacity(0.9),
                  ),
                  contentPadding: EdgeInsets.symmetric(vertical: 16.0),
                  floatingLabelStyle:
                      TextStyle(color: Colors.grey.shade400, fontSize: 20),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
