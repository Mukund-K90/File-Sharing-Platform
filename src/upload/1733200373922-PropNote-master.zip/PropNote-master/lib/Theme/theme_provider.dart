import 'package:flutter/material.dart';

import '../common/utils/colors.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeData _lightTheme = ThemeData.light().copyWith(
    // Define custom colors for light theme
    scaffoldBackgroundColor: Colors.white, // Example: White background for light theme
    // Add more custom colors as needed
  );

  ThemeData _darkTheme = ThemeData.dark().copyWith(
    // Define custom colors for dark theme
    scaffoldBackgroundColor: backgroundDark, // Example: Black background for dark theme
    // Add more custom colors as needed
  );

  ThemeData _currentTheme = ThemeData.light(); // Default to light theme
  ThemeData getLightTheme() => _lightTheme;

  ThemeData getDarkTheme() => _darkTheme;
  ThemeData getTheme() => _currentTheme;

  void setTheme(ThemeData newTheme) {
    _currentTheme = newTheme;
    notifyListeners();
  }

  void toggleTheme() {
    _currentTheme = _currentTheme == _lightTheme ? _darkTheme : _lightTheme;
    notifyListeners();
  }
}
