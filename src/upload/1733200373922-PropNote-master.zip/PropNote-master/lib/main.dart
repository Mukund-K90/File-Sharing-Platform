import 'dart:ui';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:propnote/common/user_active_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Pages/Dashboard/Property_Models/add_property.dart';
import 'Pages/Dashboard/dashboard_screen.dart';
import 'Pages/Dashboard/drawer/about_contact_us.dart';
import 'Pages/Dashboard/drawer/profile.dart';
import 'Pages/Welcome/splash_screen.dart';
import 'Pages/home_page.dart';
import 'Pages/mobile_authentication/phone.dart';
import 'Pages/mobile_authentication/verify_mobile.dart';

Color color1 = const Color(0xffaf9f84);
Color color2 = const Color(0xfff3d05e);
Color color3 = Colors.black;

void main() async {
  // Ensure Flutter bindings are initialized
  WidgetsFlutterBinding.ensureInitialized();

  // // Initialize Firebase if needed
  await Firebase.initializeApp();

  // Initialize SharedPreferences
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? storedMobileNumber = prefs.getString(SplashScreenState.KEYUSERNAME);

  runApp(MyApp(storedMobileNumber: storedMobileNumber));
}

class MyApp extends StatelessWidget {
  final String? storedMobileNumber;

  const MyApp({super.key, this.storedMobileNumber});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: 'SplashScreen',
      routes: {
        'SplashScreen': (context) => const SplashScreen(),
        'MyPhone': (context) => const MyPhone(),
        'MyVerify': (context) => const MyVerify(),
        'ActiveContactPage':(context)=> UserActivePage(),
        'HomePage': (context) => HomePage(mobile: storedMobileNumber ?? ''),
        'DashboardScreen': (context) => DashboardScreen(),
        'Profile': (context) => Profile(),
        'AboutUs': (context) => const AboutMe(),
        'ContactUs': (context) => const ContactUs(),
        'AddProperty': (context) => const AddProperty(),
      },
    );
  }
}
