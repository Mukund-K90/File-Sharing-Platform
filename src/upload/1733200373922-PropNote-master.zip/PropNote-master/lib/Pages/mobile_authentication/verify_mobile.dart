import 'dart:async';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:propnote/Pages/mobile_authentication/phone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Theme/theme_provider.dart';
import '../../common/user_mobile.dart';
import '../../common/utils/colors.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';

import '../../model/database.dart';
import '../../model/phone_auth_helper.dart';
import '../Welcome/splash_screen.dart';

class MyVerify extends StatefulWidget {
  const MyVerify({super.key});

  @override
  State<MyVerify> createState() => _MyVerifyState();
}

class _MyVerifyState extends State<MyVerify> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  late Timer _timer;
  int _start = 60;
  bool _canResend = false;
  String code = "";

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _canResend = false;
    _start = 60; // Set the timer to 1 minute (60 seconds)
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_start == 0) {
        setState(() {
          timer.cancel();
          _canResend = true;
        });
      } else {
        setState(() {
          _start--;
        });
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(
          fontSize: 20,
          color: Color.fromRGBO(30, 60, 87, 1),
          fontWeight: FontWeight.w600),
      decoration: BoxDecoration(
        border: Border.all(color: const Color.fromRGBO(234, 239, 243, 1)),
        borderRadius: BorderRadius.circular(20),
      ),
    );

    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: const Color.fromRGBO(114, 178, 238, 1)),
      borderRadius: BorderRadius.circular(8),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        color: const Color.fromRGBO(234, 239, 243, 1),
      ),
    );

    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Container(
        margin: const EdgeInsets.only(left: 25, right: 25),
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/Images/verify_phone.png',
                width: 150,
                height: 150,
              ),
              const SizedBox(
                height: 25,
              ),
              const Text(
                "Phone Verification",
                style: TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold, color: tealBlue),
              ),
              const SizedBox(
                height: 10,
              ),
              const Text(
                "We need to register your phone without getting started!",
                style: TextStyle(
                  color: tealBlue,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              TextButton(
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      'MyPhone',
                          (route) => false,
                    );
                  },
                  child: const Text(
                    "Wrong number ?",
                    style: TextStyle(color: blueLight),
                  )),
              const SizedBox(
                height: 30,
              ),
              Pinput(
                length: 6,
                defaultPinTheme: defaultPinTheme,
                focusedPinTheme: focusedPinTheme,
                submittedPinTheme: submittedPinTheme,
                showCursor: true,
                onChanged: (v) {
                  code = v;
                },
                onCompleted: (pin) => print(pin),
              ),
              const SizedBox(
                height: 20,
              ),
              SizedBox(
                width: double.infinity,
                height: 45,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: tealBlue,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    onPressed: () async {
                      try {
                        var userCredential =
                        await PhoneAuthHelper.signInWithOTP(
                            MyPhone.verify, code);

                        if (userCredential != null) {
                          var user = FirebaseAuth.instance.currentUser;
                          if (user != null) {
                            bool userExists =
                            await checkIfUserExists(user.phoneNumber ?? "");

                            if (userExists) {
                              var userStatus =
                              await getUserStatus(user.phoneNumber ?? "");
                              if (userStatus?['Status'] == true) {
                                Navigator.pushReplacementNamed(
                                    context, 'DashboardScreen');
                              } else {
                                Navigator.pushReplacementNamed(
                                    context, 'ActiveContactPage');
                              }
                            } else {
                              showVerificationDialog(
                                context: context,
                                title: 'Error',
                                dialogType: DialogType.error,
                                onContinue: () {
                                  Navigator.pop(context);
                                },
                                btnTitle: 'Re-Enter',
                              );
                            }
                          } else {
                            showVerificationDialog(
                              context: context,
                              title: 'Error',
                              dialogType: DialogType.error,
                              onContinue: () {
                                Navigator.pop(context);
                              },
                              btnTitle: 'Re-Enter',
                            );
                          }
                        } else {
                          showVerificationDialog(
                            context: context,
                            title:
                            'Wrong OTP\nPlease enter a valid 6-digit OTP',
                            dialogType: DialogType.error,
                            btnTitle: 'Re-Enter',
                            onContinue: () {
                              Navigator.pop(context);
                            },
                          );
                          print('Wrong OTP');
                        }
                      } catch (e) {
                        print('Error: $e');
                      }
                    },
                    child: const Text(
                      "Verify Phone Number",
                      style: TextStyle(color: Colors.white),
                    )),
              ),
              const SizedBox(
                height: 30,
              ),
              _canResend
                  ? TextButton(
                onPressed: () async {
                  // Request a new OTP
                  await PhoneAuthHelper.verifyPhoneNumber(
                      context, userMobile); // use the correct mobile number
                  // Reset the timer
                  _startTimer();
                },
                child: const Text(
                  "Resend OTP",
                  style: TextStyle(color: blueLight),
                ),
              )
                  : Text("You can resend OTP in $_start seconds"),
            ],
          ),
        ),
      ),
    );
  }

  void showVerificationDialog({
    required BuildContext context,
    required String title,
    required DialogType dialogType,
    required VoidCallback onContinue,
    String btnTitle = 'Continue',
  }) {
    AwesomeDialog(
      dismissOnBackKeyPress: false,
      context: context,
      dismissOnTouchOutside: false,
      title: title,
      titleTextStyle: const TextStyle(fontSize: 15, color: Colors.grey),
      dialogType: dialogType,
      btnOk: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
        onPressed: onContinue,
        child: Text(
          btnTitle,
          style:
          const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    ).show();
  }
}
