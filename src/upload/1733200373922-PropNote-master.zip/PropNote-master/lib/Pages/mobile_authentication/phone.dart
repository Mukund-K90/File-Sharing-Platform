import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../common/utils/colors.dart';
import '../../model/database.dart';
import '../../model/phone_auth_helper.dart';
import '../Welcome/splash_screen.dart';

class MyPhone extends StatefulWidget {
  const MyPhone({Key? key}) : super(key: key);
  static String verify = "";

  @override
  State<MyPhone> createState() => _MyPhoneState();
}

class _MyPhoneState extends State<MyPhone> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController countryController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  var phone = "";

  @override
  void initState() {
    countryController.text = "+91";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.only(left: 25, right: 25),
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/Images/phone_verification.png',
                  width: 150,
                  height: 150,
                ),
                RichText(
                    textAlign: TextAlign.center,
                    text: const TextSpan(
                        text: "Phone Verifications\n",
                        style: TextStyle(fontSize: 22, color: tealBlue),
                        children: [
                          TextSpan(
                              style: TextStyle(fontSize: 16),
                              text: "Please entered your register mobile no")
                        ])),
                const SizedBox(
                  height: 30,
                ),
                Container(
                  height: 55,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.grey),
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        width: 10,
                      ),
                      SizedBox(
                        width: 40,
                        child: TextField(
                          controller: countryController,
                          keyboardType: TextInputType.number,
                          style: const TextStyle(color: tealBlue),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      const Text(
                        "|",
                        style: TextStyle(fontSize: 33, color: Colors.grey),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Builder(
                          builder: (BuildContext context) {
                            return TextFormField(
                              style: const TextStyle(color: tealBlue),
                              controller: mobileController,
                              onChanged: (v) {
                                phone = v;
                              },
                              maxLength: 10,
                              keyboardType: TextInputType.phone,
                              decoration: const InputDecoration(
                                hintStyle: TextStyle(color: Colors.grey),
                                counterText: '',
                                border: InputBorder.none,
                                hintText: "10 digit mobile",
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  width: double.infinity,
                  height: 45,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: tealBlue,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      onPressed: () async {
                        if (countryController.text.isNotEmpty &&
                            mobileController.text.isNotEmpty) {
                          if (mobileController.text.length != 10) {
                            // Show Snackbar for invalid mobile number length
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                backgroundColor: tealBlue,
                                content: Text(
                                    'Please enter a 10-digit phone number'),
                              ),
                            );
                          } else {
                            // Construct the full phone number with country code
                            String fullPhoneNumber = '${countryController.text + phone}';
                            MyPhone.verify=fullPhoneNumber;

                            // Check if the user is already authenticated with this phone number
                            bool userExists = await checkIfUserExists(fullPhoneNumber);
                            if (userExists) {
                              // If user exists, navigate to the verification page
                              // Start the phone number verification process
                              Center(child: CircularProgressIndicator(),);
                             PhoneAuthHelper.verifyPhoneNumber(context, fullPhoneNumber);

                              var sharedPref =
                              await SharedPreferences.getInstance();
                              sharedPref.setString(SplashScreenState.KEYUSERNAME,
                                  fullPhoneNumber);
                            } else {
                              // If user doesn't exist, show error message
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  backgroundColor: tealBlue,
                                  content: Text('User not found or not Active.'),
                                ),
                              );
                            }

                          }
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              backgroundColor: tealBlue,
                              content: Text(
                                  "Country Code or Phone number is required"),
                            ),
                          );
                        }
                      },

                      child: const Text(
                        "Send the code",
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold),
                      )),
                ),
                const SizedBox(
                  height: 20,
                ),
                const Divider(
                  thickness: 2,
                ),
                TextButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, 'HomePage');
                    },
                    child: const Text(
                      'New User?',
                      style: TextStyle(color: Colors.blue,fontSize: 15),
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
