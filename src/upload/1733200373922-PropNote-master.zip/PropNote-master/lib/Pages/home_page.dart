import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Reusable_Widget/ReusableTextField.dart';
import '../Reusable_Widget/custom_elevated_btn.dart';
import '../common/utils/colors.dart';
import '../model/database.dart';
import '../model/phone_auth_helper.dart';
import 'Welcome/splash_screen.dart';

class HomePage extends StatefulWidget {
  final String mobile;

  HomePage({required this.mobile, Key? key});

  static String verify = "";

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController nameController = TextEditingController();
  TextEditingController countryController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final FirestoreService _firestoreService = FirestoreService();
  final FirebaseAuth auth = FirebaseAuth.instance;
  var phone = "";

  @override
  void initState() {
    countryController.text = "+91";
    phone = "";
    super.initState();
    widget.mobile;
  }

  String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  String? validateMobile(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your contact number';
    }
    final mobileRegex = RegExp(r'^[0-9]{10}$');
    if (!mobileRegex.hasMatch(value)) {
      return 'Please enter a valid 10-digit contact number';
    }
    return null;
  }

  Future<void> _handleSubmit(BuildContext context) async {
    if (mobileController.text.isEmpty || emailController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all details'),
          backgroundColor: tealBlue,
        ),
      );
      return;
    }

    final emailError = validateEmail(emailController.text);
    final mobileError = validateMobile(mobileController.text);

    if (mobileError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(mobileError)),
      );
      return;
    }
    if (emailError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(emailError),
          backgroundColor: tealBlue,
        ),
      );
      return;
    }

    setState(() {
      phone = countryController.text + mobileController.text;
    });

    bool userExists = await checkIfUserExists(phone);

    if (userExists) {
      // User exists, check if active or not
      var userStatus = await getUserStatus(phone);
      if (userStatus?['Status'] == true) {
        Navigator.pushReplacementNamed(context, 'DashboardScreen');
      } else {
        Navigator.pushReplacementNamed(context, 'ActiveContactPage');
      }
    } else {
      // User does not exist, create a new user
      PhoneAuthHelper.verifyPhoneNumber(context, phone);
      NewUser newUser = NewUser(
        isActive: false,
        name: nameController.text,
        mobile: phone,
        email: emailController.text,
      );
      await _firestoreService.addUserData(newUser);
      var sharedPref = await SharedPreferences.getInstance();
      sharedPref.setBool(SplashScreenState.KEYLOGIN, true);
      sharedPref.setString(SplashScreenState.KEYUSERNAME, phone);

      Navigator.pushReplacementNamed(context, 'ActiveContactPage');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 30),
              child: Image(
                image: AssetImage('assets/Images/create_profile.png'),
                width: 200,
                height: 200,
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  children: [
                    const Text(
                      "Create Account",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: tealBlue,
                      ),
                    ),
                    Form(
                      child: Column(
                        children: [
                          ReusableTextField(
                            controller: nameController,
                            title: "Name",
                            keyboardType: TextInputType.name,
                          ),
                          ReusableTextField(
                            controller: emailController,
                            title: "Email-Id",
                            keyboardType: TextInputType.emailAddress,
                            validator: validateEmail,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Container(
                              height: 55,
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(width: 1, color: Colors.grey),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                children: [
                                  const SizedBox(
                                    width: 15,
                                  ),
                                  SizedBox(
                                    width: 40,
                                    child: TextField(
                                      controller: countryController,
                                      keyboardType: TextInputType.phone,
                                      style: const TextStyle(color: tealBlue),
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                  const Text(
                                    "|",
                                    style: TextStyle(
                                        fontSize: 33, color: Colors.grey),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    child: Builder(
                                      builder: (BuildContext context) {
                                        return TextFormField(
                                          style:
                                              const TextStyle(color: tealBlue),
                                          controller: mobileController,
                                          onChanged: (v) {
                                            phone = v;
                                          },
                                          maxLength: 10,
                                          keyboardType: TextInputType.phone,
                                          decoration: const InputDecoration(
                                            hintStyle:
                                                TextStyle(color: Colors.grey),
                                            counterText: '',
                                            border: InputBorder.none,
                                            hintText: "10 digit mobile",
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          CustomElevatedButton(
                            onPressed: () async {
                              _handleSubmit(context);
                              // await auth.signInWithCredential(MyVerify.credential);
                            },
                            text: "Create Account",
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          const Divider(
                            thickness: 2,
                          ),
                          TextButton(
                              onPressed: () {
                                Navigator.pushReplacementNamed(
                                    context, 'MyPhone');
                              },
                              child: const Text(
                                'Already User?',
                                style:
                                    TextStyle(color: Colors.blue, fontSize: 15),
                              ))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
