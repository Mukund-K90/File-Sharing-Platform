import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../model/database.dart'; // Import the file where getUserStatus is defined

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {
  static const String KEYLOGIN = "login";
  static const String KEYUSERNAME = 'username';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _checkInternetConnection();
    });
  }

  Future<void> _checkInternetConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      showDialogBox(); // Show the dialog if no internet
      print('No internet');
    } else {
      whereToGo(); // Check where to navigate if internet is available
      print('Internet Connected');
    }
  }

  showDialogBox() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('NO INTERNET'),
        content: const Text('Please check your Internet connection'),
        actions: [
          CupertinoButton.filled(
            child: const Text('Retry'),
            onPressed: () {
              Navigator.pop(context); // Close the dialog
              _checkInternetConnection(); // Retry internet connection check
            },
          ),
        ],
      ),
    );
  }

  Future<void> whereToGo() async {
    var sharedPref = await SharedPreferences.getInstance();
    var isLoggedIn = sharedPref.getBool(KEYLOGIN) ?? false;
    var username = sharedPref.getString(KEYUSERNAME) ?? 'NO USER';

    if (isLoggedIn) {
      var userStatus = await getUserStatus(username);
      Timer(const Duration(seconds: 5), () {
        if (userStatus?['Status'] == true) {
          Navigator.pushReplacementNamed(context, 'DashboardScreen');
        } else {
          Navigator.pushReplacementNamed(context, 'ActiveContactPage');
        }
      });
    } else {
      Timer(const Duration(seconds: 5), () {
        Navigator.pushReplacementNamed(context, 'MyPhone');
      });
    }

    if (kDebugMode) {
      print('Username: $username');
      print('isLoggedIn: $isLoggedIn');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Lottie.asset('assets/Lottie/SplashScreen.json')),
    );
  }
}
