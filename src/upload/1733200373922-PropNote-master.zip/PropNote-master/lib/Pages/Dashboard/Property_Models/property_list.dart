import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:propnote/Pages/Dashboard/Property_Models/property_view.dart';

import '../../../Reusable_Widget/custom_elevated_btn.dart';
import '../../../common/user_mobile.dart';
import '../../../common/utils/colors.dart';

class ProductList extends StatefulWidget {
  String selectedCategory;
  String selectedType;
  String selectedArea;

  ProductList(this.selectedCategory, this.selectedType, this.selectedArea);

  @override
  State<ProductList> createState() => _ProductListState();
}

class _ProductListState extends State<ProductList> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _buildQuery().snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(
              color: tealBlue,
            ),
          );
        }
        if (snapshot.hasError) {
          return Center(
            child: Text('Error: ${snapshot.error}'),
          );
        }
        if (snapshot.hasData) {
          final List<QueryDocumentSnapshot> documents = snapshot.data!.docs;
          if (documents.isEmpty) {
            return Center(
              child: Image.asset('assets/Images/no-data-found.png'),
            );
          }
          return ListView.builder(
            physics: AlwaysScrollableScrollPhysics(),
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            itemCount: documents.length,
            itemBuilder: (context, index) {
              final propertyData =
              documents[index].data() as Map<String, dynamic>;
              return _buildProductListItem(propertyData);
            },
          );
        }
        return Center(
          child: Text('No data available'),
        );
      },
    );
  }

  Query _buildQuery() {
    Query<Map<String, dynamic>> query = _firestore.collection('Users').doc(userMobile).collection('properties');

    // Apply filters based on selectedCategory and selectedType
    if (widget.selectedCategory.isNotEmpty) {
      query = query.where('Category', isEqualTo: widget.selectedCategory);
    }
    if (widget.selectedType.isNotEmpty) {
      query = query.where('Type', isEqualTo: widget.selectedType);
    }
    if (widget.selectedArea.isNotEmpty) {
      query = query.where('Area', isEqualTo: widget.selectedArea);
    }

    return query;
  }

  Widget _buildProductListItem(Map<String, dynamic> propertyData) {
    // Fetch ImageUrls as List<String>
    final List<String> imageUrls = List<String>.from(propertyData['ImageUrls']);

    // Fetch other necessary data
    final int totalImages = imageUrls.length;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PropertyDetailsScreen(propertyData),
          ),
        );
      },
      child: Column(
        children: [
          SizedBox(
            height: 150,
            child: Row(
              children: [
                Expanded(
                  flex: 4,
                  child: Stack(
                    children: [
                      if (imageUrls.isNotEmpty)
                        Image.network(
                          imageUrls[0], // Display the first image
                          height: double.infinity,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            print('Error loading image: $error');
                            return Center(child: Text('Error loading image'));
                          },
                        ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          height: 28,
                          padding: EdgeInsets.symmetric(horizontal: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                FontAwesomeIcons.images,
                                color: Colors.white,
                                size: 15,
                              ),
                              SizedBox(width: 10),
                              Text(
                                '$totalImages',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 6,
                  child: Column(
                    children: [
                      ListTile(
                        title: Text(propertyData['Title'] ?? ''),
                        subtitle: Text(propertyData['Description'] ?? ''),
                      ),
                      Expanded(
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              CustomElevatedButton2(
                                onPressed: () {},
                                isTitle: false,
                                icon: FontAwesomeIcons.sms,
                                bgColor: Colors.transparent,
                              ),
                              CustomElevatedButton2(
                                onPressed: () {},
                                isTitle: false,
                                icon: FontAwesomeIcons.phone,
                                iconColor: Colors.white,
                                bgColor: tealBlue,
                              ),
                              CustomElevatedButton2(
                                onPressed: () {},
                                isTitle: false,
                                icon: FontAwesomeIcons.whatsapp,
                                iconColor: Colors.white,
                                bgColor: tealBlue,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Divider(),
          ),
        ],
      ),
    );
  }
}
