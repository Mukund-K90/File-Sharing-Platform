import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../Reusable_Widget/custom_elevated_btn.dart';
import '../../../common/user_mobile.dart';
import '../../../common/utils/colors.dart';

class PropertyDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> propertyData;

  PropertyDetailsScreen(this.propertyData);

  @override
  Widget build(BuildContext context) {
    final List<String> imageUrls = List<String>.from(propertyData['ImageUrls']);
    final int totalImages = imageUrls.length;
final String address='${propertyData['Address']},${propertyData['Area']}-${propertyData['Pincode']}.';
final String clientMobile='+91'+'${propertyData['Client Mobile']}';
    return Scaffold(
      appBar: AppBar(
        title: Text(propertyData['Title'] ?? 'Property Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              // Navigate to edit screen
              // Implement navigation logic here
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () {
              // Implement delete logic
              _deleteProperty(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 300,
              child: Stack(
                children: [
                  CarouselSlider(
                    options: CarouselOptions(
                      height: double.infinity,
                      aspectRatio: 16 / 9,
                      viewportFraction: 1.0,
                      enableInfiniteScroll: true,
                      autoPlay: true,
                      autoPlayInterval: const Duration(seconds: 3),
                      autoPlayAnimationDuration:
                          const Duration(milliseconds: 800),
                      autoPlayCurve: Curves.fastOutSlowIn,
                      scrollDirection: Axis.horizontal,
                    ),
                    items: imageUrls.map((imageUrl) {
                      return Builder(
                        builder: (BuildContext context) {
                          return Image.network(
                            imageUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              print('Error loading image: $error');
                              return const Center(
                                  child: Icon(FontAwesomeIcons.images));
                            },
                          );
                        },
                      );
                    }).toList(),
                  ),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      height: 28,
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            FontAwesomeIcons.images,
                            color: Colors.white,
                            size: 15,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            '$totalImages',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  ListTile(
                    title: Text(
                      '₹${propertyData['Price']}/-',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                      ),
                    ),
                    subtitle: Text(
                        address),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Row(
                        children: [
                          Icon(
                            FontAwesomeIcons.layerGroup,
                            color: tealBlue,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            '${propertyData['Property Size']}',
                            style: TextStyle(fontSize: 15),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Icon(
                            FontAwesomeIcons.idBadge,
                            color: tealBlue,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            '${propertyData['ID']}',
                            style: TextStyle(fontSize: 15),
                          )
                        ],
                      )
                    ],
                  ),
                  Divider(),
                  Container(
                    color: Colors.teal.shade50,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                              child: Text(
                            'Features and Amenities',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          )),
                          Row(
                            children: [
                              Icon(
                                FontAwesomeIcons.check,
                                color: tealBlue,
                                size: 15,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                '${propertyData['Features']}',
                                style: TextStyle(fontSize: 15),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  Divider(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                          child: Text(
                            'Client Details',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          )),
                      Row(
                        children: [
                          Icon(
                            FontAwesomeIcons.solidUser,
                            color: tealBlue,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            '${propertyData['Client Name']}',
                            style: TextStyle(fontSize: 17),
                          )
                        ],
                      )
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            CustomElevatedButton2(
              onPressed: () {
                // Implement SMS button logic
                sendSMS();
              },
              isTitle: false,
              icon: FontAwesomeIcons.sms,
              bgColor: Colors.transparent,
            ),
            CustomElevatedButton2(
              onPressed: () {
                _makePhoneCall(clientMobile);
              },
              isTitle: false,
              icon: FontAwesomeIcons.phone,
              iconColor: Colors.white,
              bgColor: tealBlue,
            ),
            CustomElevatedButton2(
              onPressed: () {
                String phoneNumber = clientMobile; // Replace with your WhatsApp number
                String message = 'Hi'; // Replace with your message

                String url = 'https://wa.me/$phoneNumber/?text=${Uri.encodeComponent(message)}';
                launchURL(url);
              },
              isTitle: false,
              icon: FontAwesomeIcons.whatsapp,
              iconColor: Colors.white,
              bgColor: tealBlue,
            ),
          ],
        ),
      ),
    );
  }
  void sendSMS() async {
    // Phone number to send SMS to
    const String phoneNumber = '+919624533286'; // Replace with recipient's phone number

    // Message to send
    const String message = 'Hello from Mukund';

    // Create the SMS URL with the phone number and message
    final Uri smsUri = Uri(
      scheme: 'sms',
      path: phoneNumber,
      queryParameters: {'body': message},
    );

    // Launch the SMS app
    try {
      await launch(smsUri.toString());
    } catch (e) {
      print('Error launching SMS: $e');
    }
  }

  void _makePhoneCall(String phoneNumber) async {
    final String url = 'tel:$phoneNumber';

    try {
      await launch(url);
    } catch (e) {
      throw 'Could not launch phone call:$e';
    }
  }
  void launchURL(String url) async {
    try {
      await launch(url);
    } catch (e) {
      print('Error launching URL: $e');
    }
  }
  void _deleteProperty(BuildContext context) async {
    final String documentId = propertyData['documentId'] as String;
    try {
      await FirebaseFirestore.instance
          .collection('Users')
          .doc(userMobile)
          .collection('properties')
          .doc(documentId)
          .delete();
      Navigator.pop(context); // Navigate back to previous screen after deletion
    } catch (e) {
      print('Error deleting property: $e');
    }
  }
}
