import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:intl/intl.dart';
import '../../../Reusable_Widget/ReusableTextField.dart';
import '../../../Reusable_Widget/custom_elevated_btn.dart';
import '../../../common/user_mobile.dart';
import '../../../common/utils/colors.dart';
import '../../../lists.dart';
import '../../../model/database.dart';

class AddProperty extends StatefulWidget {
  const AddProperty({Key? key}) : super(key: key);

  @override
  State<AddProperty> createState() => _AddPropertyState();
}

class _AddPropertyState extends State<AddProperty> {
  final ImagePicker _imagePicker = ImagePicker();
  List<String> _imageFileList = [];
  int _currentImageIndex = 0;
  final DateTime date = DateTime.now();

  /*============Controller===================*/
  final TextEditingController title =
      TextEditingController(text: kDebugMode ? "Title 1" : "");
  final TextEditingController description =
      TextEditingController(text: kDebugMode ? "Description 1" : "");
  final TextEditingController price =
      TextEditingController(text: kDebugMode ? "4500000" : "");
  final TextEditingController propertySize =
      TextEditingController(text: kDebugMode ? "20*48" : "");
  final TextEditingController features =
      TextEditingController(text: kDebugMode ? "Good" : "");
  final TextEditingController clientName =
      TextEditingController(text: kDebugMode ? "Niteshbhai" : "");
  final TextEditingController clientMobile =
      TextEditingController(text: kDebugMode ? "9854723014" : "");
  final TextEditingController address1 =
      TextEditingController(text: kDebugMode ? "Surat" : "");
  final TextEditingController address2 =
      TextEditingController(text: kDebugMode ? "Gujarat" : "");
  final TextEditingController pincodeController =
      TextEditingController(text: kDebugMode ? "395006" : "");

  /*===============================*/
  String selectedCategory = 'Home';
  String selectedType = '';
  String selectedArea = 'Varachha';

  List<String> CategoryList = [];

  @override
  void initState() {
    super.initState();
    getUserMobile();
  }

  void _selectImages() async {
    final List<XFile>? selectedImages = await _imagePicker.pickMultiImage();
    if (selectedImages != null && selectedImages.isNotEmpty) {
      setState(() {
        _imageFileList.addAll(selectedImages.map((image) => image.path));
      });
    }
  }

  void updateTypeList(String MainCategory) {
    // Get the subject list based on the selected program and program term
    CategoryList = SubjectLists.getSubjects(MainCategory);
    setState(() {
      //selectedSubject = subjectList.isNotEmpty ? subjectList[0] : null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final String publishDate = DateFormat('dd-MM-yyyy hh:mm a').format(date);
    return Scaffold(
      appBar: AppBar(
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20),
        backgroundColor: tealBlue,
        title: const Text('Add Property'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            children: [
              _imageFileList.isNotEmpty
                  ? CarouselSlider(
                      options: CarouselOptions(
                        height: 200,
                        viewportFraction: 0.8,
                        enlargeCenterPage: true,
                        autoPlay: true,
                        onPageChanged: (index, reason) {
                          setState(() {
                            _currentImageIndex = index;
                          });
                        },
                      ),
                      items: _imageFileList.map((String imageFile) {
                        return Builder(
                          builder: (BuildContext context) {
                            return SizedBox(
                              width: double.infinity,
                              child: Image.file(
                                File(imageFile),
                                fit: BoxFit.cover,
                              ),
                            );
                          },
                        );
                      }).toList(),
                    )
                  : Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        height: 150,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: Colors.grey.shade200,
                            image: const DecorationImage(
                                image: AssetImage(
                                    'assets/Images/no_img_found.png'))),
                      ),
                    ),
              Text(
                _imageFileList.isEmpty
                    ? '0/0'
                    : '${_currentImageIndex + 1}/${_imageFileList.length}',
                style: const TextStyle(color: Colors.grey, fontSize: 15),
              ),
              const SizedBox(
                height: 10,
              ),
              Center(
                  child: CustomElevatedButton(
                      onPressed: () {
                        _selectImages();
                      },
                      text: 'Add Image *')),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Divider(
                  thickness: 3,
                  color: tealBlue,
                ),
              ),
              const Center(
                child: Text(
                  'Property Details',
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Divider(
                  thickness: 3,
                  color: tealBlue,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Form(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: ListTile(
                              title: const Text(
                                "Category",
                                style: TextStyle(fontSize: 15),
                              ),
                              subtitle: DropdownButtonFormField(
                                  validator: (value) {
                                    if (value!.isEmpty ||
                                        selectedCategory == "None") {
                                      return "Please Select Main Category";
                                    }
                                  },
                                  decoration: const InputDecoration(
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.all(Radius.zero))),
                                  value: selectedCategory,
                                  items: [
                                    DropdownMenuItem(
                                      value: '',
                                      child: Text('None'),
                                    ),
                                    ...lists.mainCategory
                                        .map((e) => DropdownMenuItem(
                                              value: e,
                                              child: Text(e),
                                            ))
                                  ],
                                  onChanged: (val) {
                                    setState(() {
                                      selectedCategory = val as String;
                                      selectedType = '';
                                      updateTypeList(selectedCategory);
                                    });
                                  }),
                            ),
                          ),
                          Expanded(
                            child: ListTile(
                              title: const Text(
                                "Type",
                                style: TextStyle(fontSize: 15),
                              ),
                              subtitle: DropdownButtonFormField(
                                  validator: (value) {
                                    if (value!.isEmpty ||
                                        selectedType == "None") {
                                      return "Please Select Type";
                                    }
                                  },
                                  decoration: const InputDecoration(
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.all(Radius.zero))),
                                  value: selectedType,
                                  items: [
                                    DropdownMenuItem(
                                      value: '',
                                      child: Text('None'),
                                    ),
                                    ...CategoryList.map((e) => DropdownMenuItem(
                                          value: e,
                                          child: Text(e),
                                        ))
                                  ],
                                  onChanged: (val) {
                                    setState(() {
                                      selectedType = val as String;
                                    });
                                  }),
                            ),
                          ),
                        ],
                      ),
                      ReusableTextField(
                        title: 'Title',
                        controller: title,
                      ),
                      ReusableTextField(
                        isRequired: true,
                        title: 'Description',
                        controller: description,
                        maxLines: 3,
                        keyboardType: TextInputType.multiline,
                      ),
                      ReusableTextField(
                        title: 'Price',
                        controller: price,
                        keyboardType: TextInputType.number,
                      ),
                      ReusableTextField(
                        title: 'Property Size (square feet or square meters)',
                        controller: propertySize,
                      ),
                      ReusableTextField(
                        isRequired: false,
                        controller: features,
                        title: 'Features and Amenities (Optional)',
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(
                          thickness: 3,
                          color: tealBlue,
                        ),
                      ),
                      const Center(
                        child: Text(
                          'Client Details',
                          style: TextStyle(
                              fontSize: 25, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(
                          thickness: 3,
                          color: tealBlue,
                        ),
                      ),
                      ReusableTextField(
                        title: 'Name',
                        controller: clientName,
                      ),
                      ReusableTextField(

                        title: 'Mobile No.',
                        controller: clientMobile,
                        keyboardType: TextInputType.number,
                        maxLength: 10,
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(
                          thickness: 3,
                          color: tealBlue,
                        ),
                      ),
                      const Center(
                        child: Text(
                          'Location Details',
                          style: TextStyle(
                              fontSize: 25, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(
                          thickness: 3,
                          color: tealBlue,
                        ),
                      ),
                      ReusableTextField(
                        title: 'Address Line 1',
                        controller: address1,
                      ),
                      ReusableTextField(
                        title: 'Address Line 2',
                        isRequired: false,
                        controller: address2,
                      ),
                      ListTile(
                        title: const Text(
                          "Area",
                          style: TextStyle(fontSize: 15),
                        ),
                        subtitle: DropdownButtonFormField(
                            validator: (value) {
                              if (value!.isEmpty || selectedArea == "None") {
                                return "Please Select Type";
                              }
                              return null;
                            },
                            decoration: const InputDecoration(
                                border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.zero))),
                            value: selectedArea,
                            items: [
                              const DropdownMenuItem(
                                value: '',
                                child: Text('None'),
                              ),
                              ...lists.areas.map((e) => DropdownMenuItem(
                                    value: e,
                                    child: Text(e),
                                  ))
                            ],
                            onChanged: (val) {
                              setState(() {
                                selectedArea = val as String;
                              });
                            }),
                      ),
                      ReusableTextField(
                        keyboardType: TextInputType.number,
                        title: 'Pincode',
                        controller: pincodeController,

                      ),
                      CustomElevatedButton(
                          onPressed: () async {
                            print("USer Mobile For Property is ${userMobile}");
                            String address =
                                address1.text + ',' + address2.text;

                            // Validate if all required fields are filled
                            if (title.text.isNotEmpty &&
                                description.text.isNotEmpty &&
                                price.text.isNotEmpty &&
                                propertySize.text.isNotEmpty &&
                                _imageFileList.isNotEmpty &&
                                selectedCategory != 'None' &&
                                selectedType != 'None' &&
                                clientName.text.isNotEmpty &&
                                clientMobile.text.isNotEmpty &&
                                address1.text.isNotEmpty &&
                                selectedArea != 'None') {
                              // Show CircularProgressIndicator while adding the property

                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  backgroundColor: tealBlue,
                                  content: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Adding Property...',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      CircularProgressIndicator(
                                        color: Colors.white,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                              try {
                                // Create NewProperty object
                                NewProperty newProperty = NewProperty(
                                  imageUrls: _imageFileList,
                                  // Join the list of image paths
                                  category: selectedCategory,
                                  type: selectedType,
                                  title: title.text,
                                  description: description.text,
                                  price: int.parse(price.text),
                                  propertySize: propertySize.text,
                                  clientName: clientName.text,
                                  clientMobile: int.parse(clientMobile.text),
                                  address: address,
                                  area: selectedArea,
                                  pincode: int.parse(pincodeController.text),
                                  // Update with actual pincode value
                                  date: publishDate,
                                  featuresAmenities: features.text
                                );


                                // Call addProperty method to add the property
                                await AddPropertyService().addProperty(
                                    userMobile, newProperty, _imageFileList);


                                // Show success message in a SnackBar
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: tealBlue,
                                    content: Text(
                                      'Property added successfully!',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                );

                                // Clear all fields after property addition
                                title.clear();
                                description.clear();
                                price.clear();
                                propertySize.clear();
                                features.clear();
                                clientName.clear();
                                clientMobile.clear();
                                address1.clear();
                                address2.clear();
                                pincodeController.clear();
                                setState(() {
                                  _imageFileList.clear();
                                  selectedCategory = '';
                                  selectedType = '';
                                  selectedArea = '';
                                });

                                // Navigate to dashboard after property is added
                                Navigator.pushReplacementNamed(
                                    context, 'DashboardScreen');
                              } catch (e) {
                                // Show error message in a SnackBar
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: Colors.red,
                                    content: Text(
                                      'Failed to add property. Please try again later.',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                );
                              }
                            } else {
                              // Show error message if any required fields are empty
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: tealBlue,
                                  content: Text(
                                    'Please fill all required fields data',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              );
                            }
                          },
                          text: 'Add Property'),
                      const SizedBox(
                        height: 20,
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
