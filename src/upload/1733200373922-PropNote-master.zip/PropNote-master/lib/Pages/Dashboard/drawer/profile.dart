import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Reusable_Widget/custom_elevated_btn.dart';
import '../../../common/user_mobile.dart';
import '../../../common/utils/colors.dart';
import '../../../model/database.dart';
import '../../Welcome/splash_screen.dart';

class Profile extends StatefulWidget {


  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  FirestoreService firestoreService = FirestoreService();
  @override
  void initState() {
    super.initState();
    getUserMobile();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: FutureBuilder<NewUser?>(
        future: firestoreService.getUserDataByMobile(userMobile),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else {
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (snapshot.hasData && snapshot.data != null) {
              NewUser user = snapshot.data!;
              return ListView(
                padding: EdgeInsets.all(16.0),
                children: [
                  ListItem(
                    title: 'ID',
                    subtitle: user.userId.toString(),
                    icon: FontAwesomeIcons.idCard,
                  ),
                  ListItem(
                    title: 'Name',
                    subtitle: user.name.toString(),
                    icon: FontAwesomeIcons.solidUser,
                  ),
                  ListItem(
                    title: 'Email',
                    subtitle: user.email.toString(),
                    icon: FontAwesomeIcons.solidEnvelope,
                  ),
                  ListItem(
                    title: 'Mobile No.',
                    subtitle: user.mobile.toString(),
                    icon: FontAwesomeIcons.phone,
                  ),

                  SizedBox(
                    height: 20,
                  ),
                  CustomElevatedButton2(
                    text: 'LOG OUT !!',
                      onPressed: () async{
                        var sharedPref = await SharedPreferences.getInstance();
                        sharedPref.remove(SplashScreenState.KEYLOGIN);
                        sharedPref.setString(SplashScreenState.KEYUSERNAME, '');
                        Navigator.pushReplacementNamed(context, 'SplashScreen');
                      },
                      bgColor: tealBlue)
                ],
              );
            } else {
              return Center(child: Text('User not found'));
            }
          }
        },
      ),
    );
  }
}

class ListItem extends StatelessWidget {
  final String title;
  final String subtitle;

  final IconData? icon;

  ListItem({
    required this.title,
    required this.subtitle,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        height: 44,
        width: 44,
        decoration: BoxDecoration(
            color: tealBlue, borderRadius: BorderRadius.circular(14)),
        child: Icon(
          icon,
          color: Colors.white,
        ),
      ),
      title: Text(
        title,
        style: TextStyle(color: Colors.grey),
      ),
      subtitle: Text(
        subtitle,
        style: TextStyle(fontSize: 15),
      ),
    );
  }
}
