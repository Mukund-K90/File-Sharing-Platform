import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../common/utils/colors.dart';
import '../../../main.dart';

const Color textColor = Colors.grey;

class AboutMe extends StatelessWidget {
  const AboutMe({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        children: const [
          Text('Team Aarambh',textAlign: TextAlign.center,style: TextStyle(fontSize: 30),),
          SizedBox(height: 20,),
          Text(
            textAlign: TextAlign.justify,
            "Passionate Flutter developer eager to leverage skills in mobile app development. Strong problem-solving abilities with a dedication to crafting efficient and user-friendly applications. Committed to continuous learning and contributing to innovative projects in a collaborative environment.",
          ),
          SizedBox(height: 20),
          Text(
            "O U R  W O R K E X P E R I E N C E",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: tealBlue,
            ),
          ),
          Text(
            "eCollege",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "\u2022 The eCollege app is an advanced educational platform designed to enhance the learning experience for students and streamline administrative processes for educational institutions. Built using Flutter, this cross-platform mobile application aims to provide a seamless and user-friendly interface for students, faculty, and administrators.",
            style: TextStyle(color: textColor),
            textAlign: TextAlign.justify, // Set the text alignment to justify
          ),
          SizedBox(height: 20),
          Text(
            "Portfolio App",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
              textAlign: TextAlign.justify,
              style: TextStyle(color: textColor),
              "\u2022 In this Flutter portfolio app, I present a comprehensive overview of user's skills, projects, and availability for hire. The 'About Me' section provides a succinct introduction, highlighting user's expertise in Flutter development. The 'Projects' section offers a visual showcase of user's work. With a clear 'Hire Me' option, Iexpress readiness for freelance or full-timeopportunities, backed by provided contact information."),
          SizedBox(height: 20),
          Text(
            "ChatOn",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
              textAlign: TextAlign.justify,
              style: TextStyle(color: textColor),
              "\u2022 Currently, I'm passionately engaged in developing a chat application named ChatOn. With completion of 3-4 pages of its user interface (UI), Through meticulous attention to detail and a keen eye for design, each UI element is thoughtfully constructed to enhance usability and engagement"),
          SizedBox(height: 20,)
        ],
      ),
    );
  }
}

class MyCard extends StatelessWidget {
  late String img;
  late String title;

  MyCard({super.key, required this.img, required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Image(
          image: AssetImage(img),
          height: 70,
          width: 70,
        ),
        Text(
          '${title}',
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

class ContactUs extends StatefulWidget {
  const ContactUs({super.key});

  @override
  State<ContactUs> createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  final List Links = [
    {
      'whatsApp':
          'whatsapp://send?phone=+917862992577&text=${Uri.encodeFull('Hello!!')}',
      'instagram':
          "https://www.instagram.com/mukund_koladiya.18?utm_source=qr&igsh=MTZvY2t4Njc4cnY4bA==",
      'linkedinIn': "https://www.linkedin.com/in/koladiya-mukund-a48499239/",
      'github': "https://github.com/Mukund-K91",
      'twitter': "https://twitter.com/koladiyamukund1",
      'facebook': "https://www.facebook.com/mukund.koladiya.3",
    }
  ];
  final String emialAddress = "koladiyamukund58@gmail.com";
  final String mobile = "7862992577";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
      ),
      body: Container(
        child: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(
                  top: MediaQuery.of(context).size.height * 0.10),
              child: Column(
                children: [
                  const Text(
                    "Hello, This App is Created by",
                    style: TextStyle(fontSize: 20),
                  ),
                  const Text(
                    "Mukund H. Koladiya",
                    style: TextStyle(
                        fontSize: 35,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  ),
                  Text("Flutter Developer",
                      style: TextStyle(fontSize: 20, color: color2)),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    width: 150,
                    height: 50,
                    child: TextButton(
                      onPressed: () => _hireMe(),
                      child: const Text(
                        "Contact Us",
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      ),
                      style: TextButton.styleFrom(
                          backgroundColor: color3,
                          shape: const ContinuousRectangleBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)))),
                    ),
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['instagram']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.instagram,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['linkedinIn']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.linkedinIn,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['github']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.github,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['twitter']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.twitter,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['facebook']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.facebook,
                            color: color3,
                          ))
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  void _launchEmail(String emailAddress) async {
    final Uri _emailLaunchUri = Uri(
      scheme: 'mailto',
      path: emailAddress,
    );

    try {
      await launch(_emailLaunchUri.toString());
    } catch (e) {
      print('Error launching email: $e');
    }
  }

  void _makePhoneCall(String phoneNumber) async {
    final String url = 'tel:$phoneNumber';

    try {
      await launch(url);
    } catch (e) {
      throw 'Could not launch phone call:$e';
    }
  }

  Future<void> _hireMe() async {
    await showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return SizedBox(
          height: MediaQuery.of(context).size.height * 0.50,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('Contact Me'),
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(
                      FontAwesomeIcons.solidEnvelope,
                      color: color3,
                    ),
                    title: Text(emialAddress,
                        style: const TextStyle(color: Colors.blueAccent)),
                    onTap: () => _launchEmail(emialAddress),
                  ),
                  ListTile(
                    leading: Icon(
                      FontAwesomeIcons.phone,
                      color: color3,
                    ),
                    title: Text(
                      mobile,
                      style: const TextStyle(color: Colors.blueAccent),
                    ),
                    onTap: () => _makePhoneCall(mobile),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  const Text('-------- OR --------'),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['whatsApp']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.whatsapp,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['instagram']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.instagram,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['linkedinIn']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.linkedinIn,
                            color: color3,
                          )),
                      IconButton(
                          onPressed: () {
                            launchURL('${Links[0]['twitter']}');
                          },
                          icon: Icon(
                            FontAwesomeIcons.twitter,
                            color: color3,
                          )),
                    ],
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void launchURL(String url) async {
    try {
      await launch(url);
    } catch (e) {
      print('Error launching URL: $e');
    }
  }
}
