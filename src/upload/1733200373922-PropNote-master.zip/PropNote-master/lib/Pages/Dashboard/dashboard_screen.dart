import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../common/user_mobile.dart';
import '../../common/utils/colors.dart';
import '../../lists.dart';
import '../../model/database.dart';
import '../Welcome/splash_screen.dart';
import 'Property_Models/property_list.dart';

String selectedCategory = 'Home'; // Default to 'Home'
String selectedType = 'House'; // Default to empty string
String selectedArea = '';

class DashboardScreen extends StatefulWidget {
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late String userName = '';
  late String userEmail = '';
  late String Mobile = '';
  FirestoreService firestoreService = FirestoreService();
  final Map<String, int> _selectedOptions = {
    'Home': 0,
    'Plots': 0,
    'Commercial': 0,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    getUserMobile().then((_) {
      Mobile = userMobile;
      print('mobile is ${Mobile}');
      fetchUserData(); // Call fetchUserData after Mobile is set
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Widget _buildOptionsList(String tabName) {
    List<Map<String, dynamic>> options = [];
    if (tabName == 'Home') {
      options = [
        {'title': 'All', 'image': 'assets/Images/all.png', 'type': ''},
        {
          'title': 'House',
          'image': 'assets/Images/Home_Img/house.png',
          'type': 'House'
        },
        {
          'title': 'Flat',
          'image': 'assets/Images/Home_Img/flat.png',
          'type': 'Flat'
        },
        {
          'title': 'Farm House',
          'image': 'assets/Images/Home_Img/farm_house.png',
          'type': 'FarmHouse'
        },
        {
          'title': 'Row House',
          'image': 'assets/Images/Home_Img/row_house.png',
          'type': 'Row House'
        },
        {
          'title': 'other',
          'image': 'assets/Images/others.png',
          'type': 'other'
        },
      ];
    } else if (tabName == 'Plots') {
      options = [
        {'title': 'All', 'image': 'assets/Images/all.png', 'type': ''},
        {
          'title': 'Residential Plot',
          'image': 'assets/Images/Plots_Img/residential_plot.png',
          'type': 'Residential Plot'
        },
        {
          'title': 'Commercial Plot',
          'image': 'assets/Images/Plots_Img/commercial_plot.png',
          'type': 'Commercial Plot'
        },
        {
          'title': 'Agriculture land',
          'image': 'assets/Images/Plots_Img/agriculture_land.png',
          'type': 'Agriculture land'
        },
        {
          'title': 'Plot file',
          'image': 'assets/Images/Plots_Img/plot_file.png',
          'type': 'Plot file'
        },
        {
          'title': 'other',
          'image': 'assets/Images/others.png',
          'type': 'other'
        },
      ];
    } else if (tabName == 'Commercial') {
      options = [
        {'title': 'All', 'image': 'assets/Images/all.png', 'type': ''},
        {
          'title': 'Office',
          'image': 'assets/Images/Commercial_Img/office.png',
          'type': 'Office'
        },
        {
          'title': 'Shop',
          'image': 'assets/Images/Commercial_Img/shop.png',
          'type': 'Shop'
        },
        {
          'title': 'Warehouse',
          'image': 'assets/Images/Commercial_Img/warehouse.png',
          'type': 'Warehouse'
        },
        {
          'title': 'Factory',
          'image': 'assets/Images/Commercial_Img/factory.png',
          'type': 'Factory'
        },
        {
          'title': 'Building',
          'image': 'assets/Images/Commercial_Img/building.png',
          'type': 'Building'
        },
        {
          'title': 'other',
          'image': 'assets/Images/others.png',
          'type': 'other'
        },
      ];
    }
    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      scrollDirection: Axis.horizontal,
      itemCount: options.length,
      itemBuilder: (context, index) {
        return OptionsCard(
          title: options[index]['title'],
          onPressed: () {
            setState(() {
              _selectedOptions[tabName] = index;
              selectedCategory = tabName;
              selectedType = options[index]['type'];
            });
          },
          isSelected: index == _selectedOptions[tabName],
          img: options[index]['image'],
        );
      },
    );
  }

  // Function to fetch user data
  void fetchUserData() async {
    NewUser? user = await firestoreService.getUserDataByMobile(Mobile);
    if (user != null) {
      setState(() {
        userName = user.name ?? 'User';
        userEmail = user.email ?? 'Email';
      });
    } else {
      print('User not found or an error occurred while fetching user data.');
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("User Not Found or Active")));
      var sharedPref = await SharedPreferences.getInstance();
      sharedPref.remove(SplashScreenState.KEYLOGIN);
      sharedPref.setString(SplashScreenState.KEYUSERNAME, '');
      Navigator.pushReplacementNamed(context, 'SplashScreen');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
      ),
      drawer: Drawer(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          UserAccountsDrawerHeader(
            currentAccountPicture: CircleAvatar(
                backgroundColor: tealBlue,
                child: Icon(
                  Icons.person,
                  color: Colors.white,
                )),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/Images/dashboard_img.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            accountName: Text(
              userName,
              style: TextStyle(color: Colors.black),
            ),
            accountEmail: Text(
              userEmail,
              style: TextStyle(color: Colors.black),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'Profile');
            },
            child: const ListTile(
              leading: Icon(
                FontAwesomeIcons.idCard,
                color: Colors.teal,
              ),
              title: Text('Profile'),
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Divider(
              thickness: 2,
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              'App Control',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'AboutUs');
            },
            child: const ListTile(
              leading: Icon(
                FontAwesomeIcons.circleInfo,
                color: Colors.teal,
              ),
              title: Text('About Us'),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.pushNamed(context, 'ContactUs');
            },
            child: const ListTile(
              leading: Icon(
                FontAwesomeIcons.phone,
                color: Colors.teal,
              ),
              title: Text('Contact Us'),
            ),
          ),
          InkWell(
            onTap: () async {
              var sharedPref = await SharedPreferences.getInstance();
              sharedPref.remove(SplashScreenState.KEYLOGIN);
              sharedPref.setString(SplashScreenState.KEYUSERNAME, '');
              Navigator.pushReplacementNamed(context, 'SplashScreen');
            },
            child: const ListTile(
              leading: Icon(
                FontAwesomeIcons.phone,
                color: Colors.teal,
              ),
              title: Text('LOG OUT!!'),
            ),
          ),
          const Center(
            child: Text(
              'version 0.0.18',
              style: TextStyle(color: Colors.grey),
            ),
          )
        ],
      )),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height / 3,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/Images/dashboard_img2.png'),
                fit: BoxFit.cover,
              ),
              color: Colors.teal,
              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(40)),
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  height: 50,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: TextFormField(
                            decoration: const InputDecoration(
                              prefixIcon: Icon(
                                FontAwesomeIcons.search,
                                size: 15,
                              ),
                              border: InputBorder.none, // Remove border
                              hintText: 'Search',
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                            value: selectedArea,
                            menuMaxHeight:
                                MediaQuery.of(context).size.height / 2,
                            items: [
                              DropdownMenuItem(
                                value: '',
                                child: Text(
                                  'Area',
                                  style: TextStyle(color: Colors.grey),
                                ),
                              ),
                              ...lists.areas.map((e) => DropdownMenuItem(
                                    value: e,
                                    child: Text(e),
                                  ))
                            ],
                            onChanged: (val) {
                              setState(() {
                                selectedArea = val!;
                              });
                            },
                            icon: Icon(Icons.arrow_drop_down),
                            // Set the icon for the dropdown button
                            // You can customize the icon size and color here
                            iconSize: 24, // Adjust the size of the arrow icon
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          Container(
            height: 120, // Adjust height as needed
            color: Colors.teal,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(topRight: Radius.circular(30)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    TabBar(
                      labelColor: Colors.teal,
                      dividerColor: Colors.teal,
                      controller: _tabController,
                      indicatorColor: Colors.teal,
                      unselectedLabelColor: Colors.grey,
                      tabs: const [
                        Tab(text: 'Home'),
                        Tab(text: 'Plots'),
                        Tab(text: 'Commercial'),
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        controller: _tabController,
                        children: [
                          _buildOptionsList('Home'),
                          _buildOptionsList('Plots'),
                          _buildOptionsList('Commercial'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
              child: ProductList(selectedCategory, selectedType, selectedArea))
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: tealBlue,
        onPressed: () {
          Navigator.pushNamed(context, 'AddProperty');
        },
        child: const Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
    );
  }
}

class OptionsCard extends StatelessWidget {
  final String title;
  final String img;
  final VoidCallback onPressed;
  final bool isSelected;

  const OptionsCard({
    super.key,
    required this.title,
    required this.img,
    required this.onPressed,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isSelected ? Colors.teal : Colors.grey.shade200,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Image(
                image: AssetImage(img),
                color: isSelected ? Colors.white : Colors.grey,
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isSelected ? Colors.white : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
