import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Pages/Welcome/splash_screen.dart';
import '../Pages/home_page.dart';
import '../Pages/mobile_authentication/phone.dart';
import '../common/user_mobile.dart';

class PhoneAuthHelper {
  static Future<void> verifyPhoneNumber(BuildContext context, String fullPhoneNumber) async {
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: fullPhoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) {
          // Automatically sign in the user on verification completion
        },
        verificationFailed: (FirebaseAuthException e) {
          // Handle verification failure
        },
        codeSent: (String verificationId, int? resendToken) async {
          userMobile = fullPhoneNumber;
          MyPhone.verify = verificationId;
          HomePage.verify = verificationId;
          Navigator.pushReplacementNamed(context, 'MyVerify');

          var sharedPref = await SharedPreferences.getInstance();
          sharedPref.setBool(SplashScreenState.KEYLOGIN, true);
          sharedPref.setString(SplashScreenState.KEYUSERNAME, fullPhoneNumber);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          // Handle code auto retrieval timeout
        },
      );
    } catch (e) {
      // Handle other exceptions
    }
  }

  static Future<UserCredential?> signInWithOTP(String verificationId, String smsCode) async {
    FirebaseAuth auth = FirebaseAuth.instance;
    try {
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
          verificationId: MyPhone.verify,
          smsCode: smsCode
      );

      var sharedPref = await SharedPreferences.getInstance();
      sharedPref.setBool(SplashScreenState.KEYLOGIN, true);
      sharedPref.setString(SplashScreenState.KEYUSERNAME, userMobile);

      return await auth.signInWithCredential(credential);
    } catch (e) {
      // Handle exceptions
      return null;
    }
  }
}
