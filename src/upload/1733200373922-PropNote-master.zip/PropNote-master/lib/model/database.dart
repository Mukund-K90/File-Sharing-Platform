import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart' as Path;

final FirebaseFirestore _firestore = FirebaseFirestore.instance;

class NewUser {
  final int? userId;
  final String? name;
  final String? mobile;
  final String? email;
  bool? isActive;

  NewUser({
    this.userId,
    this.name,
    this.mobile,
    this.email,
    this.isActive,
  });

  Map<String, dynamic> toMap() {
    return {
      'User Id': userId,
      'Name': name,
      'Mobile': mobile,
      'Email': email,
      'Status':isActive
    };
  }
}

class FirestoreService {
  // Get the highest user ID from the Users collection
  Future<int> _getNextUserId() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('Users')
          .orderBy('User Id', descending: true)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        int highestUserId = snapshot.docs.first['User Id'];
        return highestUserId + 1;
      } else {
        return 101; // Starting ID if no users exist
      }
    } catch (e) {
      print('Error fetching highest user ID: $e');
      return 101; // Default starting ID if an error occurs
    }
  }

  // Add user data with auto-incremented user ID
  Future<void> addUserData(NewUser user) async {
    try {
      int nextUserId = await _getNextUserId();
      NewUser newUser = NewUser(
        userId: nextUserId,
        name: user.name,
        mobile: user.mobile,
        email: user.email,
        isActive: user.isActive
      );

      await _firestore
          .collection('Users')
          .doc(user.mobile)
          .set(newUser.toMap());
      print('Data Added For Id:${newUser.userId}');
    } catch (e) {
      print('Error adding user: $e');
    }
  }

  Future<NewUser?> getUserDataByMobile(String mobileNumber) async {
    try {
      DocumentSnapshot snapshot =
          await _firestore.collection('Users').doc(mobileNumber).get();

      if (snapshot.exists) {
        return NewUser(
          userId: snapshot['User Id'],
          name: snapshot['Name'],
          mobile: snapshot['Mobile'],
          email: snapshot['Email'],
          isActive: snapshot['Status']
        );
      } else {
        print('User with mobile number $mobileNumber does not exist');
        return null;
      }
    } catch (e) {
      print('Error fetching user data by mobile: $e');
      return null;
    }
  }
}

Future<bool> checkIfUserExists(String mobileNumber) async {
  try {
    // Attempt to get the document with the provided mobile number
    var userDoc = await FirebaseFirestore.instance
        .collection('Users')
        .doc(mobileNumber)
        .get();

    // If the document exists, the user exists
    if (userDoc.exists) {
      var userData = userDoc.data();
      if (userData?['Status'] == true) {
        print('User exists and is active');
        return true;
      } else {
        print('User exists but is not active');
        // Handle case where user exists but is not active
        // You might throw an exception, return a specific error code, etc.
        // For simplicity, returning false here
        return false;
      }
    } else {
      print('User does not exist');
      return false;
    }
  } catch (e) {
    // Handle any errors
    print('Error checking user existence: $e');
    return false;
  }
}

Future<Map<String, dynamic>?> getUserStatus(String mobileNumber) async {
  try {
    // Attempt to get the document with the provided mobile number
    var userDoc = await FirebaseFirestore.instance
        .collection('Users')
        .doc(mobileNumber)
        .get();

    // If the document exists, return the user's data
    if (userDoc.exists) {
      var userData = userDoc.data();
      return userData;
    } else {
      print('User does not exist');
      return null;
    }
  } catch (e) {
    // Handle any errors
    print('Error fetching user status: $e');
    return null;
  }
}
/*==========================================================================*/
/*==========================================================================*/
/*========================Add Property API==================================*/
/*==========================================================================*/
/*==========================================================================*/

class NewProperty {
  String? id; // Optional field for property ID
  final List<String> imageUrls;
  final String category;
  final String type;
  final String title;
  final String description;
  final int price;
  final String propertySize;
  final String? featuresAmenities;
  final String clientName;
  final int clientMobile;
  final String date;
  final String address;
  final String area;
  final int pincode;

  NewProperty({
    this.id, // Make ID optional
    required this.imageUrls,
    required this.category,
    required this.type,
    required this.title,
    required this.description,
    required this.price,
    required this.propertySize,
    this.featuresAmenities,
    required this.clientName,
    required this.clientMobile,
    required this.address,
    required this.area,
    required this.pincode,
    required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'ID': id,
      'Title': title,
      'Description': description,
      'Price': price,
      'Property Size': propertySize,
      'ImageUrls': imageUrls,
      'Category': category,
      'Type': type,
      'Client Name': clientName,
      'Client Mobile': clientMobile,
      'Address': address,
      'Area': area,
      'Pincode': pincode,
      'Published Date': date,
      'Features': featuresAmenities
    };
  }

  // Method to update ID after generation
  void updateId(String id) {
    this.id = id;
  }
}

class AddPropertyService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<void> addProperty(
      String userMobile, NewProperty property, List<String> imagePaths) async {
    try {
      List<String> imageUrls = [];
      for (String imagePath in imagePaths) {
        // Upload each image to Firebase Storage
        String imageURL = await _uploadImage(imagePath);
        imageUrls.add(imageURL); // Add the imageURL to the list
      }

      // Generate the next ID based on property count and category
      int currentCount = await _getPropertyCount(userMobile);
      String id = _generateNextId(property.category, currentCount);

      // Update the property object with the generated ID
      property.updateId(id);

      // Add the property with the updated ID and image URLs list
      DocumentReference userRef =
          _firestore.collection('Users').doc(userMobile);
      await userRef.collection('properties').doc(id).set({
        ...property.toMap(),
        'ImageUrls': imageUrls,
      });

      // Increment the property count for the user
      await _incrementPropertyCount(userMobile);

      print('Property added successfully');
    } catch (e) {
      print('Error adding property: $e');
    }
  }

  Future<int> _getPropertyCount(String userMobile) async {
    DocumentSnapshot snapshot =
        await _firestore.collection('Users').doc(userMobile).get();
    Map<String, dynamic>? data =
        snapshot.data() as Map<String, dynamic>?; // Explicit casting
    return (data?['propertyCount'] ?? 0) as int;
  }

  Future<void> _incrementPropertyCount(String userMobile) async {
    await _firestore.collection('Users').doc(userMobile).update({
      'propertyCount': FieldValue.increment(1),
    });
  }

  Future<String> _uploadImage(String imagePath) async {
    Reference storageReference =
        _storage.ref().child('PropertiesImages/${Path.basename(imagePath)}');
    UploadTask uploadTask = storageReference.putFile(File(imagePath));
    TaskSnapshot taskSnapshot = await uploadTask.whenComplete(() => null);
    String imageURL = await taskSnapshot.ref.getDownloadURL();
    return imageURL;
  }

  String _generateNextId(String category, int currentCount) {
    // Generate ID with category prefix, current count, and timestamp/random number to ensure uniqueness
    String prefix = _getPrefixFromCategory(category);
    String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    return '$prefix-${currentCount.toString().padLeft(3, '0')}'; // Adjust format as per your requirements
  }

  String _getPrefixFromCategory(String category) {
    // Define your mapping of categories to prefixes here
    // Example mappings:
    Map<String, String> categoryPrefixes = {
      'Home': 'H',
      'Plots': 'P',
      'Commercial': 'C',
    };

    String defaultPrefix = 'O';

    // Check if the category exists in the map, otherwise use defaultPrefix
    return categoryPrefixes[category] ?? defaultPrefix;
  }
}
