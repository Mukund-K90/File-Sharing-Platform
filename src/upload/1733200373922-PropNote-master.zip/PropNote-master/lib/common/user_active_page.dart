import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:propnote/Reusable_Widget/custom_elevated_btn.dart';
import 'package:propnote/common/user_mobile.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Pages/Welcome/splash_screen.dart';
import '../model/database.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Stream to listen to changes for a specific user's data
  Stream<NewUser?> getUserDataByMobile(String mobileNumber) {
    return _firestore
        .collection('Users')
        .doc(mobileNumber)
        .snapshots()
        .map((snapshot) {
      if (snapshot.exists) {
        return NewUser(
          userId: snapshot['User Id'],
          name: snapshot['Name'],
          mobile: snapshot['Mobile'],
          email: snapshot['Email'],
          isActive: snapshot['Status'],
        );
      } else {
        print('User with mobile number $mobileNumber does not exist');
        return null;
      }
    });
  }
}

class UserActivePage extends StatefulWidget {
  @override
  _UserActivePageState createState() => _UserActivePageState();
}

class _UserActivePageState extends State<UserActivePage> {
  late Stream<NewUser?> _userStream;
  final DatabaseService _databaseService = DatabaseService();
  late String
      userMobile; // Define a global variable to store user's mobile number
  bool _isLoading = true; // Track if data loading is in progress

  @override
  void initState() {
    super.initState();
    _initUserStream();
  }

  Future<void> _initUserStream() async {
    try {
      userMobile = await getUserMobile();
      _userStream = _databaseService.getUserDataByMobile(userMobile);
      setState(() {
        _isLoading = false; // Data loading is complete
      });
    } catch (error) {
      print('Error fetching user mobile: $error');
      // Handle error scenario as needed
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Activation'),
      ),
      body: _isLoading
          ? Center(
              child:
                  CircularProgressIndicator()) // Show loading indicator while data is loading
          : StreamBuilder<NewUser?>(
              stream: _userStream,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData) {
                  return Center(child: Text('No user data found'));
                }

                final user = snapshot.data!;
                final msg =
                    "I request To active my account\nName:${user.name}\nEmail:${user.email}\nMobile:${user.mobile}\nRequest Id:A2024001";
                return Padding(
                  padding: const EdgeInsets.all(10),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("User Activation Required",
                            style: TextStyle(fontSize: 20)),
                        SizedBox(height: 20),
                        Text("Request Id:A-003625",
                            style: TextStyle(fontSize: 16)),
                        SizedBox(height: 20),
                        Text(
                          "Status: ${user.isActive != null ? (user.isActive! ? 'Active' : 'Not Active') : 'Unknown'}",
                          style: TextStyle(
                            fontSize: 16,
                            color: user.isActive == true
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                        SizedBox(height: 20),
                        if (user.isActive != true)
                          CustomElevatedButton(
                            onPressed: () {
                              _showActivationDialog(context,msg);
                            },
                            text: "Activate",
                          ),
                        SizedBox(height: 10),
                        CustomElevatedButton(
                          onPressed: () async {
                            Navigator.pushReplacementNamed(
                                context, 'SplashScreen');
                          },
                          text: "RESTART",
                        ),
                        SizedBox(height: 10),
                        CustomElevatedButton(
                          onPressed: () async {
                            var sharedPref =
                                await SharedPreferences.getInstance();
                            sharedPref.remove(SplashScreenState.KEYLOGIN);
                            sharedPref.setString(
                                SplashScreenState.KEYUSERNAME, '');
                            Navigator.pushReplacementNamed(
                                context, 'SplashScreen');
                          },
                          text: "LOG OUT!!",
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showActivationDialog(BuildContext context,String msg) {
    AwesomeDialog(
      dismissOnBackKeyPress: false,
      context: context,
      dismissOnTouchOutside: false,
      title: "Activation Process (For Early Access)",
      titleTextStyle: const TextStyle(fontSize: 15, color: Colors.grey),
      dialogType: DialogType.info,
      body: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
              "Activation Process (For Early Access)\nTo activate your account, please contact support via the following options:"),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                onPressed: () {
                  _launchURL(
                      'whatsapp://send?phone=+917862992577&text=${Uri.encodeFull(msg)}');
                },
                icon: Icon(
                  FontAwesomeIcons.whatsapp,
                  color: Colors.green,
                ),
              ),
              IconButton(
                onPressed: () {
                  _sendSMS(msg);
                },
                icon: Icon(
                  FontAwesomeIcons.message,
                  color: CupertinoColors.activeBlue,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.all(10),
            child: CustomElevatedButton2(
              text: "Close",
              onPressed: () {
                Navigator.pop(context);
              },
              bgColor: Colors.black,
            ),
          ),
        ],
      ),
    ).show();
  }

  void _launchURL(String url) async {
    try {
      await launch(url);
    } catch (e) {
      print('Error launching URL: $e');
    }
  }

  void _sendSMS(String msg) async {
    final String phoneNumber = "+917862992577";

    final Uri smsUri = Uri(
      scheme: 'sms',
      path: phoneNumber,
      queryParameters: {'body': msg},
    );

    try {
      await launch(smsUri.toString());
    } catch (e) {
      print('Error launching SMS: $e');
    }
  }
}
