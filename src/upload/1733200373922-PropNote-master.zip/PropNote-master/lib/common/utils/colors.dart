import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../Theme/theme_provider.dart';

const Color white = const Color(0xffFFFFFF);
const Color tealBlue = Color(0xff008080);
const Color tealBlueDark = Color(0xFF045D5D);
const Color blueDark = Color(0xFF53BDEB);
const Color blueLight = Color(0xFF027EB5);
const Color greyDark = Color(0xFF8696A0);
const Color greyLight = Color(0xFF667781);
const Color backgroundDark = Color(0xff002233);
const Color backgroundLight = Color(0xFFFFFFFF);
const Color greyBackground = Color(0xFF202C33);


class ThemeUtils {
  static Color getTextColor(BuildContext context) {
    final ThemeData currentTheme = Provider.of<ThemeProvider>(context, listen: false).getTheme();
    return currentTheme.brightness == Brightness.dark ? Colors.white : Colors.black;
  }
}
