import 'package:flutter/material.dart';
import 'dart:async';

class DelayedLoader extends StatefulWidget {
  final Widget nextPage;
  final int delaySeconds;

  DelayedLoader({required this.nextPage, this.delaySeconds = 5});

  @override
  _DelayedLoaderState createState() => _DelayedLoaderState();
}

class _DelayedLoaderState extends State<DelayedLoader> {
  @override
  void initState() {
    super.initState();
    _navigateAfterDelay();
  }

  Future<void> _navigateAfterDelay() async {
    await Future.delayed(Duration(seconds: widget.delaySeconds));
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => widget.nextPage),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: CircularProgressIndicator(), // You can replace this with any loading indicator
      ),
    );
  }
}
