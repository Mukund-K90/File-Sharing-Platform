import 'package:shared_preferences/shared_preferences.dart';

import '../Pages/Welcome/splash_screen.dart';

String userMobileKey = SplashScreenState.KEYUSERNAME; // Key for storing user's mobile number in SharedPreferences

String userMobile = ''; // Define a global variable to store user's mobile number

// Function to get user's mobile number from SharedPreferences
Future<String> getUserMobile() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return userMobile = prefs.getString(userMobileKey) ?? ''; // If mobile number doesn't exist, default to empty string
}

